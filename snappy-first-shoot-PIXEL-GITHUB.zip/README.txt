SNAPPY: FIRST SHOOT pixel build

Upload index.html to the root of your GitHub repository. Then Settings > Pages > Deploy from branch > main > /(root) > Save.
